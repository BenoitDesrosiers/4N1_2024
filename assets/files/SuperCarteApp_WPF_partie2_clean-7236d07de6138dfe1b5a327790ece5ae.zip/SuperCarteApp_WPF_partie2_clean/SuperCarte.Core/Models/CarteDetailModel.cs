﻿namespace SuperCarte.Core.Models;

/// <summary>
/// Classe qui contient l'information d'une carte avec le détail de ses clés étrangères
/// </summary>
public class CarteDetailModel
{
    public int CarteId { get; set; }
    public string Nom { get; set; } = null!;
    public short Vie { get; set; }
    public short Armure { get; set; }
    public short Attaque { get; set; }
    public bool EstRare { get; set; }
    public decimal PrixRevente { get; set; }

    //Les champs des tables associées via les FK
    public int CategorieId { get; set; }
    public string CategorieNom { get; set; } = null!;
    public int EnsembleId { get; set; }
    public string EnsembleNom { get; set; } = null!;
}