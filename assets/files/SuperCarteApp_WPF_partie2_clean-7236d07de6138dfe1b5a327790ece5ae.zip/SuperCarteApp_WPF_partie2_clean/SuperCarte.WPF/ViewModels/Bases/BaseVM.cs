﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SuperCarte.WPF.ViewModels.Bases;

/// <summary>
/// Classe abstraite pour du View Model
/// </summary>
public abstract class BaseVM : ObservableObject
{

}