﻿using Microsoft.Extensions.DependencyInjection;
using SuperCarte.WPF.ViewModels.Bases;

namespace SuperCarte.WPF.ViewModels;

public class MainWindowVM : BaseVM
{
    public MainWindowVM(IServiceProvider serviceProvider)
    {
        //Sélectionner le ViewModel de démarrage
        VMActif = serviceProvider.GetRequiredService<ListeCartesVM>();
    }

    public BaseVM VMActif { get; set; }
}