﻿using SuperCarte.Core.Models;
using SuperCarte.EF.Data;

namespace SuperCarte.Core.Extensions;
public static class UtilisateurCarteMapExtension
{
    public static UtilisateurCarteModel VersUtilisateurCarteModel(this UtilisateurCarte item)
    {
        return new UtilisateurCarteModel()
        {
            UtilisateurId = item.UtilisateurId,
            CarteId = item.CarteId,
            Quantite = item.Quantite
        };
    }

    public static UtilisateurCarte VersUtilisateurCarte(this UtilisateurCarteModel item)
    {
        return new UtilisateurCarte()
        {
            UtilisateurId = item.UtilisateurId,
            CarteId = item.CarteId,
            Quantite = item.Quantite
        };
    }

    public static void Copie(this UtilisateurCarteModel itemDestination, UtilisateurCarte utilisateurCarteSource, bool copierClePrimaire)
    {
        if (copierClePrimaire == true)
        {
            itemDestination.UtilisateurId = utilisateurCarteSource.UtilisateurId;
            itemDestination.CarteId = utilisateurCarteSource.CarteId;
        }

        itemDestination.Quantite = utilisateurCarteSource.Quantite;
    }
}
