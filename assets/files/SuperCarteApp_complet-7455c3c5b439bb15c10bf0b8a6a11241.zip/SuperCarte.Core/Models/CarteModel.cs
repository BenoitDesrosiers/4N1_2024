﻿namespace SuperCarte.Core.Models;

/// <summary>
/// Classe qui contient l'information d'une carte
/// </summary>
public class CarteModel
{
    public int CarteId { get; set; }
    public string Nom { get; set; } = null!;
    public short Vie { get; set; }
    public short Armure { get; set; }
    public short Attaque { get; set; }
    public bool EstRare { get; set; }
    public decimal PrixRevente { get; set; }
    public int CategorieId { get; set; }
    public int EnsembleId { get; set; }
}