﻿using SuperCarte.Core.Models;
using SuperCarte.Core.Repositories;
using SuperCarte.EF.Data;
////
using SuperCarte.Core.Extensions;
using SuperCarte.Core.Validateurs;

namespace SuperCarte.Core.Services;

/// <summary>
/// Classe qui contient les services du modèle UtilisateurCarte
/// </summary>
public class UtilisateurCarteService : IUtilisateurCarteService
{
    private readonly IUtilisateurCarteRepo _utilisateurCarteRepo;
    private readonly IValidateurPropriete<UtilisateurCarteModel> _utilisateurCarteValidateur;

    /// <summary>
    /// Constructeur
    /// </summary>
    /// <param name="utilisateurCarteRepo">Repository UtilisateurCarte</param>
    public UtilisateurCarteService(IUtilisateurCarteRepo utilisateurCarteRepo,
       IValidateurPropriete<UtilisateurCarteModel> utilisateurCarteValidateur)
    {
        _utilisateurCarteRepo = utilisateurCarteRepo;
        _utilisateurCarteValidateur = utilisateurCarteValidateur;
    }


    public async Task<List<QuantiteCarteDetailModel>> ObtenirCartesUtilisateurAsync(int utilisateurId)
    {
        return await _utilisateurCarteRepo.ObtenirCartesUtilisateurAsync(utilisateurId);
    }


    //////
    public async Task<UtilisateurCarteModel?> ObtenirAsync(int utilisateurId, int carteId)
    {
        UtilisateurCarte? utilisateurCarte = await _utilisateurCarteRepo.ObtenirParCleAsync(utilisateurId, carteId);

        return utilisateurCarte?.VersUtilisateurCarteModel();
    }
 
    ////
    public async Task<bool> AjouterAsync(UtilisateurCarteModel utilisateurCarteModel)
    {
        if ((await ValiderAsync(utilisateurCarteModel, true)).EstValide == true)
        {
            //Transformation de l'objet du modèle du domaine en objet du modèle de données
            UtilisateurCarte utilisateurCarte = utilisateurCarteModel.VersUtilisateurCarte();

            //Ajout dans repository avec enregistrement immédiat
            await _utilisateurCarteRepo.AjouterAsync(utilisateurCarte, true);

            utilisateurCarteModel.Copie(utilisateurCarte, false);

            return true;
        }
        else
        {
            return false;
        }
    }


    ////
    public async Task<ValidationModel> ValiderAsync(UtilisateurCarteModel utilisateurCarteModel, bool validerPourAjout)
    {
        if (validerPourAjout == true)
        {
            return await _utilisateurCarteValidateur.ValiderAsync(utilisateurCarteModel);
        }
        else
        {
            return await _utilisateurCarteValidateur.ValiderAsync(utilisateurCarteModel,
                nameof(utilisateurCarteModel.Quantite));
        }
    }

}