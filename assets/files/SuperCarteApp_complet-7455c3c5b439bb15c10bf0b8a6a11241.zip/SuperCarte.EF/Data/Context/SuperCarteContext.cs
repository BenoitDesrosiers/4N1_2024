﻿using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;

namespace SuperCarte.EF.Data.Context;

/// <summary>
/// Contexte pour la base de de données SuperCarte
/// </summary>
public class SuperCarteContext : DbContext
{
    private bool _executerSeed = false;

    /// <summary>
    /// Constructeur pour la migration
    /// </summary>
	public SuperCarteContext() : base()
    {

    }

    /// <summary>
    /// Constructeur pour l'utilisation en programme
    /// </summary>
    /// <param name="options">Option de la base de données</param>
    public SuperCarteContext(DbContextOptions<SuperCarteContext> options)
        : base(options)
    {
    }

#if DEBUG //Permet d'inclure cette méthode uniquement si l'application est en mode DEBUG
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        //Vérifie si la configuration n'a pas été spécifiée par un fichier de configuration
        if (optionsBuilder.IsConfigured == false)
        {
            //Aucune configuration à partir d'un fichier de configuration
            //Option de base pour la migration            
            //string? chaineConnexion = Environment.GetEnvironmentVariable("MIGRATION_CONNECTION_STRING");
            string? chaineConnexion = "Server=localhost\\SQLExpress;Database=eDA_4N1_SuperCarte;Trusted_Connection=True;Trust Server Certificate=True;";
            //Vérifie si la variable n'est pas vide
            if (string.IsNullOrEmpty(chaineConnexion) == false)
            {
                //La variable n'est pas vide, la chaine de connexion est appliquée
                optionsBuilder.UseSqlServer(chaineConnexion);

                _executerSeed = true;
            }
            else
            {
                //Il n'y a aucune chaine de connexion.
                throw new Exception("La variable MIGRATION_CONNECTION_STRING n'est pas spécifiée. Effectuez la commande suivante dans la Console du Gestionnaire de package : $env:MIGRATION_CONNECTION_STRING=\"[ma chaine de connexion]\" ");
            }
        }
    }
#endif

    /// <summary>
    /// Configuration spécifique de la base de données
    /// </summary>
    /// <param name="modelBuilder"></param>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        //Table Role
        modelBuilder.Entity<Role>(entity =>
        {
            //Spécifie le nom de la table dans la BD
            entity.ToTable("Role");

            entity.Property(t => t.Nom)
                .IsUnicode(false) //VARCHAR ou CHAR
                .HasMaxLength(25); //VARCHAR(25)   
        });

        //Table Utilisateur
        modelBuilder.Entity<Utilisateur>(entity =>
        {
            //Spécifie le nom de la table dans la BD
            entity.ToTable("Utilisateur");

            entity.Property(t => t.Prenom)
                .IsUnicode(false)
                .HasMaxLength(50);

            entity.Property(t => t.Nom)
                .IsUnicode(false)
                .HasMaxLength(50);

            entity.Property(t => t.NomUtilisateur)
                .IsUnicode(false)
                .HasMaxLength(50);

            entity.Property(t => t.MotPasseHash)
                .IsUnicode(false)
                .IsFixedLength(true) //CHAR
                .HasMaxLength(60);

            entity.HasIndex(t => t.NomUtilisateur).IsUnique(true);

            entity.HasOne(t => t.Role).WithMany(p => p.UtilisateurListe)
                .HasForeignKey(t => t.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull);

        });

        //Table Categorie
        modelBuilder.Entity<Categorie>(entity =>
        {
            //Spécifie le nom de la table dans la BD
            entity.ToTable("Categorie");

            entity.Property(t => t.Nom)
                    .IsUnicode(false)
                    .HasMaxLength(35);

            entity.Property(t => t.Description)
                    .IsUnicode(false)
                    .HasMaxLength(50);
        });

        //Table Ensemble
        modelBuilder.Entity<Ensemble>(entity =>
        {
            //Spécifie le nom de la table dans la BD
            entity.ToTable("Ensemble");

            entity.Property(t => t.Nom)
                    .IsUnicode(false)
                    .HasMaxLength(50);

            entity.Property(t => t.Disponibilite)
                .HasColumnType("DATE");
        });

        //Table Carte
        modelBuilder.Entity<Carte>(entity =>
        {
            //Spécifie le nom de la table dans la BD
            entity.ToTable("Carte");

            entity.Property(t => t.Nom)
                    .IsUnicode(false)
                    .HasMaxLength(100);

            entity.Property(t => t.PrixRevente)
                .HasPrecision(8, 2);

            entity.HasOne(t => t.Ensemble).WithMany(p => p.CarteListe)
                    .HasForeignKey(t => t.EnsembleId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

            entity.HasOne(t => t.Categorie).WithMany(p => p.CarteListe)
                    .HasForeignKey(t => t.CategorieId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
        });

        //Table UtilisateurCarte
        modelBuilder.Entity<UtilisateurCarte>(entity =>
        {
            //Spécifie le nom de la table dans la BD
            entity.ToTable("UtilisateurCarte");

            //Spécifie la clé primaire
            entity.HasKey(t => new { t.UtilisateurId, t.CarteId });

            entity.HasOne(t => t.Utilisateur).WithMany(p => p.UtilisateurCarteListe)
                    .HasForeignKey(t => t.UtilisateurId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

            entity.HasOne(t => t.Carte).WithMany(p => p.UtilisateurCarteListe)
                    .HasForeignKey(t => t.CarteId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
        });

        if (_executerSeed == true)
        {
            Seed(modelBuilder);
        }
    }

    /// <summary>
    /// Méthode qui s'occupe de la création des données
    /// </summary>
    private void Seed(ModelBuilder modelBuilder)
    {
        //Les données à ajouter
        Role[] roles =
        {
        new Role()
        {
            RoleId = 1,
            Nom = "Administrateur"
        },
        new Role()
        {
            RoleId = 2,
            Nom = "Utilisateur"
        },
    };

        Utilisateur[] utilisateurs =
        {
        new Utilisateur()
        {
            UtilisateurId = 1,
            Prenom = "François",
            Nom = "St-Hilaire",
            NomUtilisateur = "fsthilaire",
            MotPasseHash = "$2y$11$IY6NG9FkTSI1dnjLfSbuOuNkuyI7IZHxHSOD5Td6AlwvroUz/vzLK", //Native3! avec Bcrypt
            RoleId = 1 //Admin
        },
        new Utilisateur()
        {
            UtilisateurId = 2,
            Prenom = "Benoit",
            Nom = "Tremblay",
            NomUtilisateur = "btremblay",
            MotPasseHash = "$2y$11$ewK3YsMGQ1IMKEzJUAjyVe0P19I0gEbTO998mwfVbSSA8nZ6MG/ha", //Web4MVC! avec Bcrypt
            RoleId = 2 //Utilisateur
        },
        new Utilisateur()
        {
            UtilisateurId = 3,
            Prenom = "Tony",
            Nom = "Stark",
            NomUtilisateur = "tstark",
            MotPasseHash = "$2y$11$VfcNowkWResPQKl0AA3MJ.w1LXBqmMM77YKlyf32Glr9TWG4xxyD2", //#NotAdmin! avec Bcrypt
            RoleId = 2 //Utilisateur
        }
    };

        Categorie[] categories =
        {
            new Categorie()
            {
                CategorieId = 1,
                Nom = "Animaux magiques",
                Description = null
            },
            new Categorie()
            {
                CategorieId = 2,
                Nom = "Orcs",
                Description = "Les orcs sont une race de guerrier."
            },
            new Categorie()
            {
                CategorieId = 3,
                Nom = "Mages",
                Description = "Les mages ont des pouvoirs magiques."
            }
        };

        modelBuilder.Entity<Categorie>().HasData(categories);

        Ensemble[] ensembles =
        {
            new Ensemble()
            {
                EnsembleId = 1,
                Nom = "Ensemble de départ",
                Disponibilite = new DateTime(2020,5,12)
            }
        };

        modelBuilder.Entity<Ensemble>().HasData(ensembles);

        Carte[] cartes =
        {
            new Carte()
            {
                CarteId = 1,
                Nom = "Lion des marais",
                Armure = 0,
                Vie = 12,
                Attaque = 2,
                EstRare = false,
                PrixRevente = 0.02m,
                CategorieId = 1,
                EnsembleId = 1
            },
            new Carte()
            {
                CarteId = 2,
                Nom = "Corbeau vampire",
                Armure = 0,
                Vie = 2,
                Attaque = 12,
                EstRare = true,
                PrixRevente = 1.20m,
                CategorieId = 1,
                EnsembleId = 1
            },
            new Carte()
            {
                CarteId = 3,
                Nom = "Grunty",
                Armure = 5,
                Vie = 25,
                Attaque = 5,
                EstRare = false,
                PrixRevente = 0.20m,
                CategorieId = 2,
                EnsembleId = 1
            },
            //Nouvelles cartes
            new Carte()
            {
                CarteId = 4,
                Nom = "Rider",
                Armure = 11,
                Vie = 45,
                Attaque = 35,
                EstRare = true,
                PrixRevente = 3.98m,
                CategorieId = 2,
                EnsembleId = 1
            },
            new Carte()
            {
                CarteId = 5,
                Nom = "Troll",
                Armure = 0,
                Vie = 25,
                Attaque = 15,
                EstRare = false,
                PrixRevente = 0.19m,
                CategorieId = 2,
                EnsembleId = 1
            },
            new Carte()
            {
                CarteId = 6,
                Nom = "Dragon de glace",
                Armure = 10,
                Vie = 35,
                Attaque = 10,
                EstRare = false,
                PrixRevente = 0.09m,
                CategorieId = 1,
                EnsembleId = 1
            }


        };


        UtilisateurCarte[] utilisateurCartes =
        {
            new UtilisateurCarte()
            {
                UtilisateurId = 1, //fsthilaire
                CarteId = 1, //Lion des marais
                Quantite = 2
            },
            new UtilisateurCarte()
            {
                UtilisateurId = 1, //fsthilaire
                CarteId = 3, //Grunty
                Quantite = 3
            },
            new UtilisateurCarte()
            {
                UtilisateurId = 1, //fsthilaire
                CarteId = 4, //Rider
                Quantite = 1
            },
            new UtilisateurCarte()
            {
                UtilisateurId = 1, //fsthilaire
                CarteId = 2, //Corbeau vampire
                Quantite = 5
            },
            new UtilisateurCarte()
            {
                UtilisateurId = 3, //tstark
                CarteId = 1, //Lion des marais
                Quantite = 5
            },
            new UtilisateurCarte()
            {
                UtilisateurId = 3, //tstark
                CarteId = 3, //Grunty
                Quantite = 1
            },
            new UtilisateurCarte()
            {
                UtilisateurId = 3, //tstark
                CarteId = 6, //Dragon de glace
                Quantite = 2
            },
        };
        modelBuilder.Entity<Carte>().HasData(cartes);
        //Ajout dans les tables
        modelBuilder.Entity<Role>().HasData(roles);
        modelBuilder.Entity<Utilisateur>().HasData(utilisateurs);
        modelBuilder.Entity<UtilisateurCarte>().HasData(utilisateurCartes);
    }
    public DbSet<Role> RoleTb { get; set; }

    public DbSet<Utilisateur> UtilisateurTb { get; set; }

    public DbSet<Categorie> CategorieTb { get; set; }

    public DbSet<Ensemble> EnsembleTb { get; set; }

    public DbSet<Carte> CarteTb { get; set; }

    public DbSet<UtilisateurCarte> UtilisateurCarteTb { get; set; }
}