﻿using SuperCarte.Core.Models;
using SuperCarte.EF.Data;
using SuperCarte.Core.Extensions;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using AutoFixture;

namespace SuperCarte.UTest.Core.Extensions;
public class UtilisateurMapExtensionTest
{


    [Fact]
    public void VersUtilisateurModel_CreerObjet_ValeursIdentiques()
    {
        //Arrangement (Arrange)
        var fixture = new Fixture();
        Utilisateur utilisateur =
            fixture.Build<Utilisateur>()
                .Without(u => u.Role)
                .Without(u => u.UtilisateurCarteListe)
                .Create();

        //Action (Act)
        UtilisateurModel utilisateurModelActuel = utilisateur.VersUtilisateurModel();

        //Assertion (Assert)
        utilisateurModelActuel.Should().BeEquivalentTo(utilisateur,
            options => options.Excluding(x => x.MotPasseHash)
                              .Excluding(x => x.Role)
                              .Excluding(x => x.UtilisateurCarteListe));
    }
}
