﻿
UniversContext db = new UniversContext();
Franchise univers = db.FranchiseTb.FirstOrDefault(); //Retourne le premier univers de la base de données
Console.WriteLine($"Id : {univers.FranchiseId}");
Console.WriteLine($"Nom : {univers.Nom}");
db.Dispose();