﻿
global using Univers.EF.Data; //Les classes du modèle du contexte
global using Univers.EF.Data.Context; // La classe du contexte
global using System;
global using System.Collections.Generic;
global using System.Threading.Tasks;