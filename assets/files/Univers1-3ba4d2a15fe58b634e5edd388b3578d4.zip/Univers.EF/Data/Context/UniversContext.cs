﻿using Microsoft.EntityFrameworkCore;

namespace Univers.EF.Data.Context;

/// <summary>
/// Contexte pour la base de de données Univers
/// </summary>
public class UniversContext : DbContext
{
    private bool _executerSeed = false;

    /// <summary>
    /// Constructeur pour la migration
    /// </summary>
	public UniversContext() : base()
    {

    }

    /// <summary>
    /// Constructeur pour l'utilisation en programme
    /// </summary>
    /// <param name="options">Option de la base de données</param>
    public UniversContext(DbContextOptions<UniversContext> options)
        : base(options)
    {
    }

#if DEBUG //Permet d'inclure cette méthode uniquement si l'application est en mode DEBUG
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        //Vérifie si la configuration n'a pas été spécifiée par un fichier de configuration
        if (optionsBuilder.IsConfigured == false)
        {
            //Aucune configuration à partir d'un fichier de configuration
            //Option de base pour la migration
            //string? chaineConnexion = Environment.GetEnvironmentVariable("MIGRATION_CONNECTION_STRING");
            string? chaineConnexion = "Server=localhost\\SQLExpress;Database=eDA_4N1_Univers;Trusted_Connection=True;Trust Server Certificate=True;";
            //Vérifie si la variable n'est pas vide
            if (string.IsNullOrEmpty(chaineConnexion) == false)
            {
                //La variable n'est pas vide, la chaine de connexion est appliquée
                optionsBuilder.UseSqlServer(chaineConnexion);
                _executerSeed = true;
            }
            else
            {
                //Il n'y a aucune chaine de connexion.
                throw new Exception("La variable MIGRATION_CONNECTION_STRING n'est pas spécifiée. Effectuez la commande suivante dans la Console du Gestionnaire de package : $env:MIGRATION_CONNECTION_STRING=\"[ma chaine de connexion]\" ");
            }
        }
    }
#endif

    /// <summary>
    /// Configuration spécifique de la base de données
    /// </summary>
    /// <param name="modelBuilder"></param>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        //Table Personnage
        modelBuilder.Entity<Personnage>(entity =>
        {
            //Spécifie le nom de la table dans la BD
            entity.ToTable("Personnage");

            entity.Property(t => t.Nom)
                .IsUnicode(false) //VARCHAR ou CHAR
                .HasMaxLength(100); //VARCHAR(100)  

            entity.Property(t => t.IdentiteReelle)
                .IsUnicode(false) //VARCHAR ou CHAR
                .HasMaxLength(100); //VARCHAR(100)  
        });


        //Table Univers
        modelBuilder.Entity<Franchise>(entity =>
        {
            entity.ToTable("Franchise");

            entity.Property(t => t.Nom)
                .IsUnicode(false)
                .HasMaxLength(100);

            entity.Property(t => t.SiteWeb)
                .IsUnicode(false)
                .HasMaxLength(200);

            entity.Property(t => t.Proprietaire)
                .IsUnicode(false)
                .HasMaxLength(250);

            entity.HasIndex(t => t.Nom).IsUnique(true);
        });

        //Table Film
        modelBuilder.Entity<Film>(entity =>
        {
            entity.ToTable("Film");

            entity.Property(t => t.Titre)
                .IsUnicode(false)
                .HasMaxLength(100);
        });

        //Table Distribution
        modelBuilder.Entity<Distribution>(entity =>
        {
            entity.ToTable("Distribution");
            //spécifie la clé primaire
            entity.HasKey(t => new { t.PersonnageId, t.FilmId });

            entity.Property(t => t.Acteur)
                .IsUnicode(false)
                .HasMaxLength(100);
        });

        if (_executerSeed == true)
        {
            Seed(modelBuilder);
        }

    }

    /// <summary>
    /// Méthode qui s'occupe de la création des données
    /// </summary>
    private void Seed(ModelBuilder modelBuilder)
    {
        //Les données à ajouter
        Franchise[] univers =
        {
    new Franchise()
    {
        FranchiseId = 1,
        Nom = "Marvel",
        AnneeCreation = 1939,
        SiteWeb = "https://www.marvel.com",
        Proprietaire = "Disney"
    },
    new Franchise()
    {
        FranchiseId = 2,
        Nom = "DC Comics",
        AnneeCreation = 1934,
        SiteWeb = "https://www.dc.com",
        Proprietaire = "Warner Bros"
    },
};

        Personnage[] personnages =
        {
    new Personnage()
    {
        PersonnageId = 1,
        Nom = "Spiderman",
        IdentiteReelle = "Peter Parker",
        DateNaissance = new DateOnly(1980, 12,01),
        EstVilain = false,
        FranchiseId = 1
    },
    new Personnage()
    {
        PersonnageId = 2,
        Nom = "Iron Man",
        IdentiteReelle = "Tony Stark",
        DateNaissance = new DateOnly(1970,11,12),
        EstVilain = false,
        FranchiseId = 1
    },
    new Personnage()
    {
        PersonnageId = 3,
        Nom = "Batman",
        IdentiteReelle = "Bruce Wayne",
        DateNaissance = new DateOnly(1966,03,04),
        EstVilain = false,
        FranchiseId = 2
    },
};

        //Ajout dans les tables
        modelBuilder.Entity<Franchise>().HasData(univers);
        modelBuilder.Entity<Personnage>().HasData(personnages);
    }
    public DbSet<Personnage> PersonnageTb { get; set; }

    public DbSet<Franchise> FranchiseTb { get; set; }

    public DbSet<Film> FilmTb { get; set; }

    public DbSet<Distribution> DistributionTb { get; set; }


}