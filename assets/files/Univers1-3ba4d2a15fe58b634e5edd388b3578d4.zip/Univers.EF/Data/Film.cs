﻿namespace Univers.EF.Data;
public class Film
{
    public int FilmId { get; set; }
    public string Titre { get; set; } = null!;
    public DateOnly DateSortie { get; set; }
    public byte Etoile { get; set; }
    public int Duree { get; set; }

    public ICollection<Distribution> DistributionListe { get; set; } = new List<Distribution>();
}