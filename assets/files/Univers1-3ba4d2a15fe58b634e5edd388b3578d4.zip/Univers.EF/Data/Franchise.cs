﻿namespace Univers.EF.Data;
public class Franchise
{
    public int FranchiseId { get; set; }
    public string Nom { get; set; } = null!;
    public Int16 AnneeCreation { get; set; }
    public string? SiteWeb { get; set; }
    public string? Proprietaire { get; set; }
    public ICollection<Personnage> Personnages { get; set; } = new List<Personnage>();
}
