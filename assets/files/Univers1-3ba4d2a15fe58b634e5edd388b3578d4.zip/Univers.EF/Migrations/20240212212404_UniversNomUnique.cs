﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Univers.EF.Migrations
{
    /// <inheritdoc />
    public partial class UniversNomUnique : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Univers_Nom",
                table: "Univers",
                column: "Nom",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Univers_Nom",
                table: "Univers");
        }
    }
}
