﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Univers.EF.Migrations
{
    /// <inheritdoc />
    public partial class Seed_UniversEtPersonnage : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Univers",
                columns: new[] { "UniversId", "AnneeCreation", "Nom", "Proprietaire", "SiteWeb" },
                values: new object[,]
                {
                    { 1, (short)1939, "Marvel", "Disney", "https://www.marvel.com" },
                    { 2, (short)1934, "DC Comics", "Warner Bros", "https://www.dc.com" }
                });

            migrationBuilder.InsertData(
                table: "Personnage",
                columns: new[] { "PersonnageId", "DateNaissance", "EstVilain", "IdentiteReelle", "Nom", "UniversId" },
                values: new object[,]
                {
                    { 1, new DateOnly(1980, 12, 1), false, "Peter Parker", "Spiderman", 1 },
                    { 2, new DateOnly(1970, 11, 12), false, "Tony Stark", "Iron Man", 1 },
                    { 3, new DateOnly(1966, 3, 4), false, "Bruce Wayne", "Batman", 2 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Personnage",
                keyColumn: "PersonnageId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Personnage",
                keyColumn: "PersonnageId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Personnage",
                keyColumn: "PersonnageId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Univers",
                keyColumn: "UniversId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Univers",
                keyColumn: "UniversId",
                keyValue: 2);
        }
    }
}
