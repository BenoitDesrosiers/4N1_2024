﻿
UniversContext db = new UniversContext();
Franchise franchise = db.FranchiseTb.FirstOrDefault(); //Retourne le premier univers de la base de données
Console.WriteLine($"Id : {franchise.FranchiseId}");
Console.WriteLine($"Nom : {franchise.Nom}");
db.Dispose();