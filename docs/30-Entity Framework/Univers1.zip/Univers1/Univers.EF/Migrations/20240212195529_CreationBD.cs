﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Univers.EF.Migrations
{
    /// <inheritdoc />
    public partial class CreationBD : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FilmTb",
                columns: table => new
                {
                    FilmId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Titre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateSortie = table.Column<DateOnly>(type: "date", nullable: false),
                    Etoile = table.Column<byte>(type: "tinyint", nullable: false),
                    Duree = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FilmTb", x => x.FilmId);
                });

            migrationBuilder.CreateTable(
                name: "UniversTb",
                columns: table => new
                {
                    UniversId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nom = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AnneeCreation = table.Column<short>(type: "smallint", nullable: false),
                    SiteWeb = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Proprietaire = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UniversTb", x => x.UniversId);
                });

            migrationBuilder.CreateTable(
                name: "PersonnageTb",
                columns: table => new
                {
                    PersonnageId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nom = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IdentiteReelle = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateNaissance = table.Column<DateOnly>(type: "date", nullable: false),
                    EstVilain = table.Column<bool>(type: "bit", nullable: false),
                    UniversId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PersonnageTb", x => x.PersonnageId);
                    table.ForeignKey(
                        name: "FK_PersonnageTb_UniversTb_UniversId",
                        column: x => x.UniversId,
                        principalTable: "UniversTb",
                        principalColumn: "UniversId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PersonnageTb_UniversId",
                table: "PersonnageTb",
                column: "UniversId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FilmTb");

            migrationBuilder.DropTable(
                name: "PersonnageTb");

            migrationBuilder.DropTable(
                name: "UniversTb");
        }
    }
}
