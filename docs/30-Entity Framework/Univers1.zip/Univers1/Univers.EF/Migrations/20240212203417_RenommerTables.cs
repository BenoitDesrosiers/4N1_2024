﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Univers.EF.Migrations
{
    /// <inheritdoc />
    public partial class RenommerTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PersonnageTb_UniversTb_UniversId",
                table: "PersonnageTb");

            migrationBuilder.DropPrimaryKey(
                name: "PK_UniversTb",
                table: "UniversTb");

            migrationBuilder.DropPrimaryKey(
                name: "PK_PersonnageTb",
                table: "PersonnageTb");

            migrationBuilder.DropPrimaryKey(
                name: "PK_FilmTb",
                table: "FilmTb");

            migrationBuilder.RenameTable(
                name: "UniversTb",
                newName: "Univers");

            migrationBuilder.RenameTable(
                name: "PersonnageTb",
                newName: "Personnage");

            migrationBuilder.RenameTable(
                name: "FilmTb",
                newName: "Film");

            migrationBuilder.RenameIndex(
                name: "IX_PersonnageTb_UniversId",
                table: "Personnage",
                newName: "IX_Personnage_UniversId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Univers",
                table: "Univers",
                column: "UniversId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Personnage",
                table: "Personnage",
                column: "PersonnageId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Film",
                table: "Film",
                column: "FilmId");

            migrationBuilder.AddForeignKey(
                name: "FK_Personnage_Univers_UniversId",
                table: "Personnage",
                column: "UniversId",
                principalTable: "Univers",
                principalColumn: "UniversId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Personnage_Univers_UniversId",
                table: "Personnage");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Univers",
                table: "Univers");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Personnage",
                table: "Personnage");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Film",
                table: "Film");

            migrationBuilder.RenameTable(
                name: "Univers",
                newName: "UniversTb");

            migrationBuilder.RenameTable(
                name: "Personnage",
                newName: "PersonnageTb");

            migrationBuilder.RenameTable(
                name: "Film",
                newName: "FilmTb");

            migrationBuilder.RenameIndex(
                name: "IX_Personnage_UniversId",
                table: "PersonnageTb",
                newName: "IX_PersonnageTb_UniversId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_UniversTb",
                table: "UniversTb",
                column: "UniversId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_PersonnageTb",
                table: "PersonnageTb",
                column: "PersonnageId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_FilmTb",
                table: "FilmTb",
                column: "FilmId");

            migrationBuilder.AddForeignKey(
                name: "FK_PersonnageTb_UniversTb_UniversId",
                table: "PersonnageTb",
                column: "UniversId",
                principalTable: "UniversTb",
                principalColumn: "UniversId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
