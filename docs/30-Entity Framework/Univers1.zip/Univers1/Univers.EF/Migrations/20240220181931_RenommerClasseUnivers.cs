﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Univers.EF.Migrations
{
    /// <inheritdoc />
    public partial class RenommerClasseUnivers : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Personnage_Univers_UniversId",
                table: "Personnage");

            migrationBuilder.DropTable(
                name: "Univers");

            migrationBuilder.RenameColumn(
                name: "UniversId",
                table: "Personnage",
                newName: "FranchiseId");

            migrationBuilder.RenameIndex(
                name: "IX_Personnage_UniversId",
                table: "Personnage",
                newName: "IX_Personnage_FranchiseId");

            migrationBuilder.CreateTable(
                name: "Franchise",
                columns: table => new
                {
                    FranchiseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nom = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    AnneeCreation = table.Column<short>(type: "smallint", nullable: false),
                    SiteWeb = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: true),
                    Proprietaire = table.Column<string>(type: "varchar(250)", unicode: false, maxLength: 250, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Franchise", x => x.FranchiseId);
                });

            migrationBuilder.InsertData(
                table: "Franchise",
                columns: new[] { "FranchiseId", "AnneeCreation", "Nom", "Proprietaire", "SiteWeb" },
                values: new object[,]
                {
                    { 1, (short)1939, "Marvel", "Disney", "https://www.marvel.com" },
                    { 2, (short)1934, "DC Comics", "Warner Bros", "https://www.dc.com" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Franchise_Nom",
                table: "Franchise",
                column: "Nom",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Personnage_Franchise_FranchiseId",
                table: "Personnage",
                column: "FranchiseId",
                principalTable: "Franchise",
                principalColumn: "FranchiseId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Personnage_Franchise_FranchiseId",
                table: "Personnage");

            migrationBuilder.DropTable(
                name: "Franchise");

            migrationBuilder.RenameColumn(
                name: "FranchiseId",
                table: "Personnage",
                newName: "UniversId");

            migrationBuilder.RenameIndex(
                name: "IX_Personnage_FranchiseId",
                table: "Personnage",
                newName: "IX_Personnage_UniversId");

            migrationBuilder.CreateTable(
                name: "Univers",
                columns: table => new
                {
                    UniversId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnneeCreation = table.Column<short>(type: "smallint", nullable: false),
                    Nom = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    Proprietaire = table.Column<string>(type: "varchar(250)", unicode: false, maxLength: 250, nullable: true),
                    SiteWeb = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Univers", x => x.UniversId);
                });

            migrationBuilder.InsertData(
                table: "Univers",
                columns: new[] { "UniversId", "AnneeCreation", "Nom", "Proprietaire", "SiteWeb" },
                values: new object[,]
                {
                    { 1, (short)1939, "Marvel", "Disney", "https://www.marvel.com" },
                    { 2, (short)1934, "DC Comics", "Warner Bros", "https://www.dc.com" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Univers_Nom",
                table: "Univers",
                column: "Nom",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Personnage_Univers_UniversId",
                table: "Personnage",
                column: "UniversId",
                principalTable: "Univers",
                principalColumn: "UniversId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
