﻿using Bogus;
using GenerateurBDGestionLivre.Data;

namespace GenerateurBDGestionLivre;

public class AuteurGenerateur : Faker<Auteur>
{
    public AuteurGenerateur()
    {
        RuleFor(i => i.Prenom, GenPrenom);
        RuleFor(i => i.Nom, GenNom);
        RuleFor(i => i.Biographie, GenBiographie);
        RuleFor(i => i.DateNaissance, GenDateNaissance);
        RuleFor(i => i.DateDeces, GenDateDeces);
    }

    public Auteur Generer()
    {
        return base.Generate();
    }

    private string GenPrenom(Faker f)
    {
        //VARCHAR(50)
        return f.Name.FirstName().Tronquer(50)!;
    }

    private string GenNom(Faker f)
    {
        //VARCHAR(50)
        return f.Name.LastName().Tronquer(50)!;
    }

    private string? GenBiographie(Faker f)
    {
        //VARCHAR(5000)
        //30% d'obtenir un null
        return f.Lorem.Paragraphs(1, 3).OrNull(f, 0.3f).Tronquer(5000)!;
    }

    private DateOnly GenDateNaissance(Faker f)
    {
        //La date peut être entre 1800-01-01 et 15 ans dans le passé.
        return f.Date.BetweenDateOnly(new DateOnly(1800, 1, 1), DateOnly.FromDateTime(DateTime.Now).AddYears(-15));
    }

    private DateOnly? GenDateDeces(Faker f, Auteur auteur)
    {
        //Vérifie si la date de naissance est il y a plus de 95 ans
        if (DateTime.Now.Date.Year - auteur.DateNaissance.Year > 95)
        {
            //La date de naissance est il y a plus de 95 ans
            //Il faut obligatoirement générer une date de décès.
            //L'auteur peut être mort entre 15 et 95 ans
            return f.Date.BetweenDateOnly(auteur.DateNaissance.AddYears(15), auteur.DateNaissance.AddYears(95));
        }
        else
        {
            //La date de naissance est il y a 95 ans et moins.
            //Il y a seulement 5% de chance qu'il soit décédé.

            return f.Date.BetweenDateOnly(auteur.DateNaissance.AddYears(15), DateOnly.FromDateTime(DateTime.Now).AddDays(-5)).OrNull(f, 0.95f);
        }
    }
}