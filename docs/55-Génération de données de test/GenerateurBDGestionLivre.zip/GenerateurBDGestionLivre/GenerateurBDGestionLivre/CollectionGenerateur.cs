﻿using Bogus;
using GenerateurBDGestionLivre.Data;

namespace GenerateurBDGestionLivre;

public class CollectionGenerateur : Faker<Collection>
{
    public CollectionGenerateur()
    {
        //Pour faire l'association entre une propriété et une méthode de génération, il faut utiliser la méthode RuleFor
        RuleFor(i => i.NomCollection, GenNomCollection);
        RuleFor(i => i.Description, GenDescription);
    }

    public Collection Generer()
    {
        return base.Generate();
    }

    private string GenNomCollection(Faker f)
    {
        //La méthode Words permet de générer des mots.
        //Si aucun paramètre n'est spécifié, il y aura entre 1 et 3 mots.
        //Le type est VARCHAR(50)
        return f.Random.Words().Tronquer(50)!;
    }

    private string? GenDescription(Faker f)
    {
        //La méthode Sentence permet de générer une phrase de quelques mots.
        //Le type est VARCHAR(250)
        //La probabilité du null est de 20%
        return f.Lorem.Sentence().Tronquer(250).OrNull(f, 0.2f);
    }
}
