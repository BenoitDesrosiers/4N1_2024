﻿using System;
using System.Collections.Generic;

namespace GenerateurBDGestionLivre.Data;

public partial class Auteur
{
    public int AuteurId { get; set; }

    public string Prenom { get; set; } = null!;

    public string Nom { get; set; } = null!;

    public string? Biographie { get; set; }

    public DateOnly DateNaissance { get; set; }

    public DateOnly? DateDeces { get; set; }

    public virtual ICollection<Livre> Livre { get; set; } = new List<Livre>();
}
