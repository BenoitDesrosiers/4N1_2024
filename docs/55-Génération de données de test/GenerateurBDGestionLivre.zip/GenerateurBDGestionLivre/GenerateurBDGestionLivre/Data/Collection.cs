﻿using System;
using System.Collections.Generic;

namespace GenerateurBDGestionLivre.Data;

public partial class Collection
{
    public int CollectionId { get; set; }

    public string NomCollection { get; set; } = null!;

    public string? Description { get; set; }

    public virtual ICollection<Livre> Livre { get; set; } = new List<Livre>();
}
