﻿using System;
using System.Collections.Generic;
using GenerateurBDGestionLivre.Data;
using Microsoft.EntityFrameworkCore;

namespace GenerateurBDGestionLivre.Data.Context;

public partial class GestionLivreContext : DbContext
{
    public GestionLivreContext()
    {
    }

    public GestionLivreContext(DbContextOptions<GestionLivreContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Auteur> Auteur { get; set; }

    public virtual DbSet<Collection> Collection { get; set; }

    public virtual DbSet<Editeur> Editeur { get; set; }

    public virtual DbSet<Inventaire> Inventaire { get; set; }

    public virtual DbSet<Livre> Livre { get; set; }

    public virtual DbSet<Magasin> Magasin { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=localhost\\SQLExpress;Database=eDA_4N1_GestionLivre;Trusted_Connection=True;Trust Server Certificate=true;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Auteur>(entity =>
        {
            entity.Property(e => e.Biographie)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.Nom)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Prenom)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Collection>(entity =>
        {
            entity.Property(e => e.Description)
                .HasMaxLength(250)
                .IsUnicode(false);
            entity.Property(e => e.NomCollection)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Editeur>(entity =>
        {
            entity.Property(e => e.Nom)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.SiteWeb)
                .HasMaxLength(3000)
                .IsUnicode(false);
            entity.Property(e => e.Telephone)
                .HasMaxLength(15)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Inventaire>(entity =>
        {
            entity.HasKey(e => new { e.LivreId, e.MagasinId });

            entity.HasOne(d => d.Livre).WithMany(p => p.Inventaire)
                .HasForeignKey(d => d.LivreId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Inventaire_LivreId");

            entity.HasOne(d => d.Magasin).WithMany(p => p.Inventaire)
                .HasForeignKey(d => d.MagasinId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Inventaire_MagasinId");
        });

        modelBuilder.Entity<Livre>(entity =>
        {
            entity.Property(e => e.Categorie)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Prix).HasColumnType("decimal(5, 2)");
            entity.Property(e => e.Resume)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.Titre)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.HasOne(d => d.Collection).WithMany(p => p.Livre)
                .HasForeignKey(d => d.CollectionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Livre_CollectionId");

            entity.HasOne(d => d.Editeur).WithMany(p => p.Livre)
                .HasForeignKey(d => d.EditeurId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Livre_EditeurId");

            entity.HasMany(d => d.Auteur).WithMany(p => p.Livre)
                .UsingEntity<Dictionary<string, object>>(
                    "LivreAuteur",
                    r => r.HasOne<Auteur>().WithMany()
                        .HasForeignKey("AuteurId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_LivreAuteur_AuteurId"),
                    l => l.HasOne<Livre>().WithMany()
                        .HasForeignKey("LivreId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_LivreAuteur_LivreId"),
                    j =>
                    {
                        j.HasKey("LivreId", "AuteurId");
                    });
        });

        modelBuilder.Entity<Magasin>(entity =>
        {
            entity.HasKey(e => e.MagasinId).HasName("PK_MAgasin");

            entity.Property(e => e.Adresse)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CodePostal)
                .HasMaxLength(7)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Nom)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.Ville)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
