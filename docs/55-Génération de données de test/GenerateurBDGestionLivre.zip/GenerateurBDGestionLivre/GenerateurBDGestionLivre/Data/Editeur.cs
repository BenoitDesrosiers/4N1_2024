﻿using System;
using System.Collections.Generic;

namespace GenerateurBDGestionLivre.Data;

public partial class Editeur
{
    public int EditeurId { get; set; }

    public string Nom { get; set; } = null!;

    public string SiteWeb { get; set; } = null!;

    public string Telephone { get; set; } = null!;

    public virtual ICollection<Livre> Livre { get; set; } = new List<Livre>();
}
