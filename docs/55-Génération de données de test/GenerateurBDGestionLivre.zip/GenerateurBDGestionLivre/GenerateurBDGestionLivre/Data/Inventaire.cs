﻿using System;
using System.Collections.Generic;

namespace GenerateurBDGestionLivre.Data;

public partial class Inventaire
{
    public int LivreId { get; set; }

    public int MagasinId { get; set; }

    public short Quantite { get; set; }

    public virtual Livre Livre { get; set; } = null!;

    public virtual Magasin Magasin { get; set; } = null!;
}
