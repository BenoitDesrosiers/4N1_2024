﻿using System;
using System.Collections.Generic;

namespace GenerateurBDGestionLivre.Data;

public partial class Livre
{
    public int LivreId { get; set; }

    public string Titre { get; set; } = null!;

    public string Resume { get; set; } = null!;

    public DateOnly DatePublication { get; set; }

    public decimal Prix { get; set; }

    public short NbPage { get; set; }

    public string Categorie { get; set; } = null!;

    public int CollectionId { get; set; }

    public int EditeurId { get; set; }

    public virtual Collection Collection { get; set; } = null!;

    public virtual Editeur Editeur { get; set; } = null!;

    public virtual ICollection<Inventaire> Inventaire { get; set; } = new List<Inventaire>();

    public virtual ICollection<Auteur> Auteur { get; set; } = new List<Auteur>();
}
