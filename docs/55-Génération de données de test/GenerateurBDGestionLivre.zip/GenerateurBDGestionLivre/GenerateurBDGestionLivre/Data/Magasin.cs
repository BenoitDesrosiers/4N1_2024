﻿using System;
using System.Collections.Generic;

namespace GenerateurBDGestionLivre.Data;

public partial class Magasin
{
    public int MagasinId { get; set; }

    public string Nom { get; set; } = null!;

    public string Adresse { get; set; } = null!;

    public string Ville { get; set; } = null!;

    public string CodePostal { get; set; } = null!;

    public virtual ICollection<Inventaire> Inventaire { get; set; } = new List<Inventaire>();
}
