﻿using Bogus;
using GenerateurBDGestionLivre.Data;

namespace GenerateurBDGestionLivre;

public class EditeurGenerateur : Faker<Editeur>
{
    public EditeurGenerateur()
    {
        RuleFor(i => i.Nom, GenNom);
        RuleFor(i => i.SiteWeb, GenSiteWeb);
        RuleFor(i => i.Telephone, GenTelephone);
    }

    public Editeur Generer()
    {
        return base.Generate();
    }

    private string GenNom(Faker f)
    {
        //Le nombre de mots sera aléatoire (entre 1 et 4)
        //Il faut mettre la première lettre du nom en majuscule

        int nbMot = f.Random.Number(1, 4);
        string[] mots = new string[nbMot];

        for (int i = 0; i < nbMot; i++)
        {
            mots[i] = f.Internet.DomainWord();
        }

        string nom = string.Join(" ", mots);

        //Le type est VARCHAR(150)
        return (nom.Substring(0, 1).ToUpper() + nom.Substring(1)).Tronquer(150)!;
    }

    private string GenSiteWeb(Faker f, Editeur editeur)
    {
        //Le type est VARCHAR(3000)

        //Les espaces du nom de l'éditeur peuvent être éliminés ou remplacés par des tirets.
        //Il est possible de données des choix et de choisir en fonction d'une probabilité.

        //Il est important que les 2 tableaux soient de la même longueur.
        string[] choixRemplacement = { string.Empty, "-" };
        //La somme des probabilités doit être 1.
        //60% de retirer l'espace et 40% de mettre un tiret.
        float[] probabiliteRemplacement = { 0.6f, 0.4f };

        //La méthode WeightedRandom permet de faire un choix dans une liste en fonction de probabilité pour chacun des items.
        string valeurRemplacement = f.Random.WeightedRandom(choixRemplacement, probabiliteRemplacement);

        //La longueur maximale d'un domaine est de 63
        string domaine = editeur.Nom.ToLower().Replace(" ", valeurRemplacement).Tronquer(63)!;

        //Ajoute à la fin un suffixe de domaine.
        return ("https://www." + domaine + "." + f.Internet.DomainSuffix()).Tronquer(3000)!;
    }

    private string GenTelephone(Faker f)
    {
        //La méthode PhoneNumber peut avoir un format en paramètre.
        return f.Phone.PhoneNumber("###-###-####");
    }
}
