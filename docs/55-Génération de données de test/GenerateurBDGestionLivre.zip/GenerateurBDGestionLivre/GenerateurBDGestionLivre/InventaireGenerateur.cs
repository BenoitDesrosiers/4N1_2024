﻿using Bogus;
using GenerateurBDGestionLivre.Data;

namespace GenerateurBDGestionLivre;

public class InventaireGenerateur : Faker<Inventaire>
{
    private List<int> _lstLivreId = new List<int>();

    public InventaireGenerateur()
    {
        RuleFor(i => i.Quantite, GenQuantite);
        RuleFor(i => i.LivreId, GenLivreId);
    }

    public void Generer(Magasin magasin, int min, int max)
    {
        Faker f = new Faker();

        //Détermine le nombre d'inventaires à générer pour ce magasin
        int nbInventaire = f.Random.Number(min, max);

        //Le code ci-dessous permet de s'assurer que le même LivreId n'est pas pigé plusieurs fois.
        List<int> lstLivreIdUtilise = new List<int>();
        do
        {
            Inventaire inventaire = base.Generate();

            //Vérifie s'il y a un inventaire pour ce magasin qui a déjà ce livre
            if (magasin.Inventaire.Count(i => i.LivreId == inventaire.LivreId) == 0)
            {
                //Le livre n'a jamais été utilisé pour un inventaire de ce magasin
                //L'inventaire est ajouté à la base de données, en assignant le MagasinId du magasin en cours
                magasin.Inventaire.Add(inventaire);

                nbInventaire--;
            }

        } while (nbInventaire > 0);
    }

    public void AssignerListeLivreId(List<int> lstLivreId)
    {
        _lstLivreId.Clear();
        _lstLivreId.AddRange(lstLivreId);
    }

    private short GenQuantite(Faker f)
    {
        return f.Random.Short(0, 453);
    }

    private int GenLivreId(Faker f)
    {
        return f.PickRandom(_lstLivreId);
    }
}