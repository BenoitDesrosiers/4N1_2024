﻿using Bogus;
using GenerateurBDGestionLivre.Data;

namespace GenerateurBDGestionLivre;

public class LivreGenerateur : Faker<Livre>
{
    private List<int> _lstCollectionId = new List<int>();
    private List<int> _lstEditeurId = new List<int>();
    private List<Auteur> _lstAuteur = new List<Auteur>();

    //La liste des valeurs possibles de la contrainte CK_Livre_Categorie
    private string[] _categories = { "Jeunesse", "Biographie", "Policier" };

    public LivreGenerateur()
    {
        RuleFor(i => i.Titre, GenTitre);
        RuleFor(i => i.Resume, GenResume);
        RuleFor(i => i.DatePublication, GenDatePublication);
        RuleFor(i => i.Prix, GenPrix);
        RuleFor(i => i.NbPage, GenNbPage);
        RuleFor(i => i.Categorie, GenCategorie);
        RuleFor(i => i.CollectionId, GenCollectionId);
        RuleFor(i => i.EditeurId, GenEditeurId);
    }

    public Livre Generer()
    {
        Livre livre = base.Generate();
        GenAuteurs(livre);
        return livre;
    }

    public void AssignerListeCollectionId(List<int> lstCollectionId)
    {
        _lstCollectionId.Clear();
        _lstCollectionId.AddRange(lstCollectionId);
    }

    public void AssignerListeEditeurId(List<int> lstEditeurId)
    {
        _lstEditeurId.Clear();
        _lstEditeurId.AddRange(lstEditeurId);
    }
    public void AssignerListeAuteur(List<Auteur> lstAuteur)
    {
        //Ce n'est pas des Id, mais une liste des enregistrements Auteur.
        _lstAuteur.Clear();
        _lstAuteur.AddRange(lstAuteur);
    }

    private string GenTitre(Faker f)
    {
        //Génère une série de mots
        //VARCHAR(100)
        return f.Random.Words().Tronquer(100)!;
    }

    private string GenResume(Faker f)
    {
        //Génère entre 1 et 4 paragraphes
        //VARCHAR(5000)
        return f.Lorem.Paragraphs(1, 4).Tronquer(5000)!;
    }

    private DateOnly GenDatePublication(Faker f)
    {
        //Retourne une date dans les 25 dernières années
        return f.Date.PastDateOnly(25);
    }

    private decimal GenPrix(Faker f)
    {
        //DECIMAL(5,2) => 0.00 et 999.99
        return f.Finance.Amount(0, 999.99m);
    }

    private short GenNbPage(Faker f)
    {
        //Génère entre 20 et 5123 pages
        //TINYINT
        return f.Random.Short(20, 5123);
    }

    private string GenCategorie(Faker f)
    {
        //Selectionne une valeur dans la liste
        return f.PickRandom(_categories);
    }

    private int GenCollectionId(Faker f)
    {
        //Sélectionne un EditeurId dans la liste des CollectionId disponibles
        return f.PickRandom(_lstCollectionId);
    }

    private int GenEditeurId(Faker f)
    {
        //Sélectionne un EditeurId dans la liste des EditeurId disponibles
        return f.PickRandom(_lstEditeurId);
    }

    private void GenAuteurs(Livre livre)
    {
        //Vérifie si la liste d'auteur n'est pas vide
        if (_lstAuteur.Count > 0)
        {
            //La liste d'auteur n'est pas vide

            //Créer un Faker pour avoir un générateur de nombre
            Faker f = new Faker();
            //Permet de choisir entre 1 et 3 auteurs. S'il y a moins que 3 auteurs, le nombre maximum sera le nombre d'auteurs.
            int nbAuteur = f.Random.Number(1, Math.Min(_lstAuteur.Count, 3));

            //Le code ci-dessous permet de s'assurer que le même auteur n'est pas pigé plusieurs fois.
            do
            {
                Auteur auteurSelectionne = f.PickRandom(_lstAuteur);

                if (livre.Auteur.Contains(auteurSelectionne) == false)
                {
                    //L'auteur sélectionné est un nouvel auteur                
                    livre.Auteur.Add(auteurSelectionne);
                    nbAuteur--;
                }

            } while (nbAuteur > 0);
        }
    }
}