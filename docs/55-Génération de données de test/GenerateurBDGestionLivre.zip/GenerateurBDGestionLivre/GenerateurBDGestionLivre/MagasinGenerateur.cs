﻿using Bogus;
using GenerateurBDGestionLivre.Data;

namespace GenerateurBDGestionLivre;

public class MagasinGenerateur : Faker<Magasin>
{
    public MagasinGenerateur()
    {
        RuleFor(i => i.Nom, GenNom);
        RuleFor(i => i.Adresse, GenAdresse);
        RuleFor(i => i.Ville, GenVille);
        RuleFor(i => i.CodePostal, GenPostalCode);
    }

    public Magasin Generer()
    {
        return base.Generate();
    }

    private string GenNom(Faker f)
    {
        //VARCHAR(150)
        return f.Company.CompanyName().Tronquer(150)!;
    }

    private string GenAdresse(Faker f)
    {
        //VARCHAR(100)
        return f.Address.StreetAddress().Tronquer(100)!;
    }

    private string GenVille(Faker f)
    {
        //VARCAHR(100)
        return f.Address.City().Tronquer(100)!;
    }

    private string GenPostalCode(Faker f)
    {
        //Format A0A 0A0
        //? = Lettre
        //# = Chiffre
        return f.Address.ZipCode("?#? #?#");
    }

}