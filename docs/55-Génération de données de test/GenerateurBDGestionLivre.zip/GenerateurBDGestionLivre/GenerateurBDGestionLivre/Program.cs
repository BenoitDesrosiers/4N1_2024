﻿using Bogus;
using GenerateurBDGestionLivre;
using GenerateurBDGestionLivre.Data;
using GenerateurBDGestionLivre.Data.Context;

using (GestionLivreContext db = new GestionLivreContext())
{
    CollectionGenerateur generateurCollection = new CollectionGenerateur();

    for (int i = 0; i < 10; i++)
    {
        Collection collection = generateurCollection.Generer();

        Console.WriteLine($"NomCollection : {collection.NomCollection}");
        Console.WriteLine($"Description : {collection.Description}");
        Console.WriteLine();

        //Ajoute dans la base de données
        db.Add(collection);
        //Enregistre dans la base de données
        db.SaveChanges();
    }


    EditeurGenerateur generateurEditeur = new EditeurGenerateur();

    for (int i = 0; i < 10; i++)
    {
        Editeur editeur = generateurEditeur.Generer();

        Console.WriteLine($"Nom Editeur : {editeur.Nom}");
        Console.WriteLine($"Site Web : {editeur.SiteWeb}");
        Console.WriteLine($"Téléphone : {editeur.Telephone}");
        Console.WriteLine();

        //Ajoute dans la base de données
        db.Add(editeur);
        //Enregistre dans la base de données
        db.SaveChanges();
    }


    AuteurGenerateur generateurAuteur = new AuteurGenerateur();

    for (int i = 0; i < 1000; i++)
    {
        Auteur auteur = generateurAuteur.Generer();

        Console.WriteLine($"Prenom Auteur: {auteur.Prenom}");
        Console.WriteLine($"Nom : {auteur.Nom}");
        Console.WriteLine($"Date naissance : {auteur.DateNaissance}");
        Console.WriteLine($"Date décès : {auteur.DateDeces}");
        Console.WriteLine($"Biographie : {auteur.Biographie}");
        Console.WriteLine();

        //Ajoute dans la base de données
        db.Add(auteur);
        //Enregistre dans la base de données
        db.SaveChanges();
    }


    LivreGenerateur generateurLivre = new LivreGenerateur();

    //Obtenir la liste des clés EditeurId dans la base de de données
    List<int> lstEditeurId = db.Editeur.Select(e => e.EditeurId).ToList();
    //Obtenir la liste des clés CollectionId dans la base de de données
    List<int> lstCollectionId = db.Collection.Select(c => c.CollectionId).ToList();

    //Assigner la liste dans le générateur
    generateurLivre.AssignerListeEditeurId(lstEditeurId);
    //Assigner la liste dans le générateur    
    generateurLivre.AssignerListeCollectionId(lstCollectionId);

    for (int i = 0; i < 5; i++)
    {
        Livre livre = generateurLivre.Generer();

        Console.WriteLine($"Titre Livre: {livre.Titre}");
        Console.WriteLine($"Résumé : {livre.Resume}");
        Console.WriteLine($"Date publication : {livre.DatePublication}");
        Console.WriteLine($"Prix : {livre.Prix}");
        Console.WriteLine($"Nombre de pages : {livre.NbPage}");
        Console.WriteLine($"Catégories : {livre.Categorie}");
        Console.WriteLine($"CollectionId : {livre.CollectionId}");
        Console.WriteLine($"EditeurId : {livre.EditeurId}");

        Console.WriteLine();

        //Ajoute dans la base de données
        db.Add(livre);
        //Enregistre dans la base de données
        db.SaveChanges();
    }

    LivreGenerateur generateur = new LivreGenerateur();

    //Obtenir la liste des clés EditeurId dans la base de de données
    // List<int> lstEditeurId = db.Editeur.Select(e => e.EditeurId).ToList();
    //Assigner la liste dans le générateur
    generateur.AssignerListeEditeurId(lstEditeurId);

    //Obtenir la liste des clés CollectionId dans la base de de données
    //List<int> lstCollectionId = db.Collection.Select(c => c.CollectionId).ToList();
    //Assigner la liste dans le générateur    
    generateur.AssignerListeCollectionId(lstCollectionId);

    //Obtenir la liste des auteurs
    List<Auteur> lstAuteur = db.Auteur.ToList();
    //Assigner la liste dans le générateur    
    generateur.AssignerListeAuteur(lstAuteur);


    for (int i = 0; i < 5; i++)
    {
        Livre livre = generateur.Generer();

        Console.WriteLine($"Titre : {livre.Titre}");
        Console.WriteLine($"Résumé : {livre.Resume}");
        Console.WriteLine($"Date publication : {livre.DatePublication}");
        Console.WriteLine($"Prix : {livre.Prix}");
        Console.WriteLine($"Nombre de pages : {livre.NbPage}");
        Console.WriteLine($"Catégories : {livre.Categorie}");
        Console.WriteLine($"CollectionId : {livre.CollectionId}");
        Console.WriteLine($"EditeurId : {livre.EditeurId}");

        Console.WriteLine();

        //Ajoute dans la base de données
        db.Add(livre);
        //Enregistre dans la base de données
        db.SaveChanges();
    }

    MagasinGenerateur magasinGenerateur = new MagasinGenerateur();

    //Obtenir la liste des clés EditeurId dans la base de de données
    List<int> lstLivreId = db.Livre.Select(l => l.LivreId).ToList();

    InventaireGenerateur inventaireGenerateur = new InventaireGenerateur();
    inventaireGenerateur.AssignerListeLivreId(lstLivreId);


    for (int i = 0; i < 50; i++)
    {
        //Génère un magasin
        Magasin magasin = magasinGenerateur.Generer();

        //Génère les inventaires pour ce magasin
        //Il peut avoir entre 1 et tous les livres en inventaire pour ce magasin.
        inventaireGenerateur.Generer(magasin, 1, lstLivreId.Count);

        Console.WriteLine($"Nom : {magasin.Nom}");
        Console.WriteLine($"Adresse : {magasin.Adresse}");
        Console.WriteLine($"Ville : {magasin.Ville}");
        Console.WriteLine($"Code Postal : {magasin.CodePostal}");

        Console.WriteLine();

        //Ajoute dans la base de données
        //Les inventaires associés à ce magasin seront également ajoutés
        db.Add(magasin);
        //Enregistre dans la base de données
        db.SaveChanges();
    }
}

