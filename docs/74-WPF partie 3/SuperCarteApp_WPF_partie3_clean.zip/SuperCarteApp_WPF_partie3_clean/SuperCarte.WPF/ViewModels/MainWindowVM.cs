﻿using CommunityToolkit.Mvvm.Input;

namespace SuperCarte.WPF.ViewModels;

public class MainWindowVM : BaseVM
{
    private readonly INavigateur _navigateur;

    public MainWindowVM(INavigateur navigateur)
    {
        //Sélectionner le ViewModel de démarrage        
        _navigateur = navigateur;

        //Création des commandes
        NaviguerListeCartesVMCommande = new RelayCommand(_navigateur.Naviguer<ListeCartesVM>);
        NaviguerListeCategoriesVMCommande = new RelayCommand(_navigateur.Naviguer<ListeCategoriesVM>);

        //Vue initiale
        _navigateur.Naviguer<GestionUtilisateurVM, int>(0); //Pour un nouveau
                                                            //_navigateur.Naviguer<GestionUtilisateurVM, int>(1);//Pour modifier François St-Hilaire
    }

    public IRelayCommand NaviguerListeCartesVMCommande { get; private set; }

    public IRelayCommand NaviguerListeCategoriesVMCommande { get; private set; }

    public INavigateur Navigateur
    {
        get
        {
            return _navigateur;
        }
    }
}