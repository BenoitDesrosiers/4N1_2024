﻿using Microsoft.EntityFrameworkCore;
using SuperCarte.Core.Models;
using SuperCarte.Core.Repositories.Bases;
using SuperCarte.EF.Data;
using SuperCarte.EF.Data.Context;

namespace SuperCarte.Core.Repositories;

/// <summary>
/// Classe qui contient les méthodes de communication avec la base de données pour la table Categorie
/// </summary>
public class CategorieRepo : BasePKUniqueRepo<Categorie, int>, ICategorieRepo
{
    /// <summary>
    /// Constructeur
    /// </summary>
    /// <param name="bd">Contexte de la base de données</param>
    public CategorieRepo(SuperCarteContext bd) : base(bd)
    {
        //Vide, il sert uniquement a recevoir le contexte et à l'envoyer à la classe parent.
    }

    public async Task<CategorieDependance?> ObtenirDependanceAsync(int categorieId)
    {
        return await (from lqCategorie in _bd.CategorieTb
                      where
                          lqCategorie.CategorieId == categorieId
                      select
                          new CategorieDependance()
                          {
                              CategorieId = lqCategorie.CategorieId,
                              NbCartes = lqCategorie.CarteListe.Count()
                          }).FirstOrDefaultAsync();
    }

    public CategorieDependance? ObtenirDependance(int categorieId)
    {
        return (from lqCategorie in _bd.CategorieTb
                where
                    lqCategorie.CategorieId == categorieId
                select
                    new CategorieDependance()
                    {
                        CategorieId = lqCategorie.CategorieId,
                        NbCartes = lqCategorie.CarteListe.Count()
                    }).FirstOrDefault();
    }
}